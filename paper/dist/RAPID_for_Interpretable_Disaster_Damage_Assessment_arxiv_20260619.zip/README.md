# RAPID arXiv LaTeX Package

This folder contains the arXiv source package for the RAPID manuscript.

## Upload Files

Include these files and folders:

```text
main.tex
references.bib
acmart.cls
ACM-Reference-Format.bst
figures/
```

In Overleaf, set `main.tex` as the main file and use pdfLaTeX. The project uses standard BibTeX with `ACM-Reference-Format`.

## Before Upload

1. Compile with pdfLaTeX and BibTeX.
2. Confirm that `main.pdf` matches the intended arXiv version.
3. Upload the source zip through the arXiv submission form.

## Files

- `main.tex`: Manuscript source using `acmart` with the `nonacm` option.
- `references.bib`: BibTeX references aligned with the converted manuscript.
- `figures/`: Eight figures extracted from the latest DOCX with descriptive file names.
- `acmart.cls`, `ACM-Reference-Format.bst`: Template files included for portability.
